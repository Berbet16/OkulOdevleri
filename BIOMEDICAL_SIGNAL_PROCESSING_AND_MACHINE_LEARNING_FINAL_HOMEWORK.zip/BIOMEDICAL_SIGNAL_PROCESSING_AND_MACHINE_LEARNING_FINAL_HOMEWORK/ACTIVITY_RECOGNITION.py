#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#!pip install plotly
import seaborn as sns
import plotly.express as px
import matplotlib.pyplot as plt
import numpy as np
from scipy.linalg import lstsq
import math
from scipy.ndimage import convolve1d
import pandas as pd
import os
import glob


# In[2]:


#Authors
#171805019 - Betül Berna Soylu
#171805030 – Gülfide Çalışkan
#171805053 - Soner Cengiz
#171805076 – Bahar Kaçtım
#181805028 – Betül Başan


# In[147]:


#os.chdir("C:/Users/Soner/Desktop/my/BIOMEDICAL/datasets/Physical Activity Dataset/")
#all_filenames = [i for i in glob.glob('label_*.csv')]
all_filenames = [i for i in glob.glob('datasets/Physical Activity Dataset/label_*.csv')]
labeled_data = pd.concat([pd.read_csv(f) for f in all_filenames], ignore_index=True)


# In[148]:


label_class = {
    'lying': 1, 'sitting': 2, 'standing': 3, 'walking': 4
}


# In[149]:


for i, label in enumerate(labeled_data["label"]):
    labeled_data["label"].iloc[i] = int(label_class[label])


# In[115]:


from scipy.signal import find_peaks
def all_r_point(x, title = ""):
    x = np.array(x.astype('int'))
    p_allR, p_allRproperties = find_peaks(x, distance=150)
    plt.figure()
    plt.title("ALL R points " + title)
    plt.plot(x)
    plt.plot(p_allR, x[p_allR.astype('int')], "x")
    plt.show()
    return p_allR

def all_prt_point(x, title = ""):
    x = np.array(nx.astype('int'))
    p_allPRT, p_allPRTproperties = find_peaks(x, prominence=[0.2],distance=30)
    plt.figure()
    plt.title("All PRT points " + title)
    plt.plot(x)
    plt.plot(p_allPRT, x[p_allPRT.astype('int')], "x")
    plt.show()
    return p_allPRT

def all_qs_point(x, title = ""):
    x = np.array(nx.astype('int'))
    p_allQS, p_allQRproperties = find_peaks(x*(-1), prominence=[0.1],distance=30)
    plt.figure()
    plt.title("ALL QS points " + title)
    plt.plot(x)
    plt.plot(p_allQS, x[p_allQS.astype('int')], "x")
    plt.show()
    return p_allQS
def all_pqrst_point(x, title = ""):
    x = np.array(nx.astype('int'))
    p_allPQRST = np.concatenate((all_prt_point(x, title),all_qs_point(x, title)))
    p_allPQRST.sort(kind='mergesort')
    plt.figure()
    plt.title("All PQRS points " + title)
    plt.plot(x)
    plt.plot(p_allPQRST, x[p_allPQRST.astype('int')], "x")
    plt.show()


# In[23]:


all_raw_data = pd.read_csv(r"\datasets\Physical Activity Dataset\all-raw-data.csv")


# In[24]:


all_raw_data.head()


# In[65]:


all_raw_data.shape


# In[116]:


#sampling frequency 360Hz
fs = 360
#lower and upper index for investigation
lower=17000
upper=18000
# generating time axis values
x = pd.Series(all_raw_data['ax'][lower:upper])
nx = pd.Series(all_raw_data['gx'][lower:upper])
tx = np.arange(x.size) / fs
plt.title("Accelator X axis - Gyroscope X axis")
plt.plot(tx, x)
plt.plot(tx, nx)
plt.legend(["Accelator X axis", "Gyroscope X axis"])
plt.show()


# In[117]:


all_pqrst_point(x=pd.Series(all_raw_data['ax'][lower:upper]), title = "of Accelerometer X Axis")


# In[118]:


all_pqrst_point(x=pd.Series(all_raw_data['gx'][lower:upper]), title = "of Gyroscope X Axis")


# In[119]:


#sampling frequency 360Hz
fs = 360
#lower and upper index for investigation
lower=17000
upper=18000
# generating time axis values
x = pd.Series(all_raw_data['ay'][lower:upper])
nx = pd.Series(all_raw_data['gy'][lower:upper])
tx = np.arange(x.size) / fs
plt.title("Accelator Y axis - Gyroscope Y axis")
plt.plot(tx, x)
plt.plot(tx, nx)
plt.legend(["Accelator Y axis", "Gyroscope Y axis"])
plt.show()


# In[120]:


all_pqrst_point(x=pd.Series(all_raw_data['ay'][lower:upper]), title = "of Accelerometer Y Axis")


# In[121]:


all_pqrst_point(x=pd.Series(all_raw_data['gy'][lower:upper]), title = "of Gyroscope Y Axis")


# In[113]:


all_pqrst_point(x=pd.Series(all_raw_data['ay'][lower:upper]), title = "of Accelerometer Y Axis")


# In[114]:


all_pqrst_point(x=pd.Series(all_raw_data['gy'][lower:upper]), title = "of Gyroscope Y Axis")


# In[122]:


#sampling frequency 360Hz
fs = 360
#lower and upper index for investigation
lower=17000
upper=18000
# generating time axis values
x = pd.Series(all_raw_data['az'][lower:upper])
nx = pd.Series(all_raw_data['gz'][lower:upper])
tx = np.arange(x.size) / fs
plt.title("Accelator Z axis - Gyroscope Z axis")
plt.plot(tx, x)
plt.plot(tx, nx)
plt.legend(["Accelator Z axis", "Gyroscope Z axis"])
plt.show()


# In[123]:


all_pqrst_point(x=pd.Series(all_raw_data['az'][lower:upper]), title = "of Accelerometer Z Axis")


# In[124]:


all_pqrst_point(x=pd.Series(all_raw_data['gz'][lower:upper]), title = "of Gyroscope Z Axis")


# In[125]:


data = all_raw_data.rolling(window=3).sum()


# In[ ]:


from sklearn.manifold import TSNE
mm = TSNE(random_state = 42, n_components=2, verbose=1, perplexity=50, n_iter=1000).fit_transform(labeled_data.drop('label',axis=1))


# In[146]:


fig = px.scatter(
    mm, x=0 ,y=1,
    color=data.label
)
fig.show()


# In[25]:


all_with_feature_extraction = pd.read_csv(r"C:\Users\Soner\Desktop\my\BIOMEDICAL\datasets\Physical Activity Dataset\all-with_feature_extraction.csv")


# In[26]:


all_with_feature_extraction.head()


# In[31]:


all_with_feature_extraction.columns


# In[35]:


lying_data = pd.read_csv(r"C:\Users\Soner\Desktop\my\BIOMEDICAL\datasets\Physical Activity Dataset\lying.csv")
sitting_data = pd.read_csv(r"C:\Users\Soner\Desktop\my\BIOMEDICAL\datasets\Physical Activity Dataset\sitting.csv")
standing_data = pd.read_csv(r"C:\Users\Soner\Desktop\my\BIOMEDICAL\datasets\Physical Activity Dataset\standing.csv")
walking_data = pd.read_csv(r"C:\Users\Soner\Desktop\my\BIOMEDICAL\datasets\Physical Activity Dataset\walking.csv")


# In[44]:


import os
import glob
os.chdir("C:/Users/Soner/Desktop/my/BIOMEDICAL/datasets/Physical Activity Dataset/")
all_filenames = [i for i in glob.glob('label_*.csv')]
labeled_data = pd.concat([pd.read_csv(f) for f in all_filenames ])


# In[45]:


labeled_data


# In[53]:


import matplotlib.pyplot as plt
import seaborn as sns
#!pip install plotly
import plotly.express as px


# In[46]:


labeled_data['label'].groupby(labeled_data['label']).count()


# In[59]:


fig = px.pie(labeled_data, names='label',width=1200)
fig.show()


# In[62]:





# In[143]:


def cross_corr(x, y):
    fig, [ax1, ax2] = plt.subplots(2, 1, sharex=True)
    ax1.xcorr(x, y, usevlines=True, maxlags=50, normed=True, lw=2)
    ax1.grid(True)

    ax2.acorr(x, usevlines=True, normed=True, maxlags=50, lw=2)
    ax2.grid(True)

    plt.show()


# In[145]:


cross_corr(np.array(all_raw_data['ax'], dtype="float"), np.array(all_raw_data['gx'], dtype="float"))


# In[150]:


from sklearn.model_selection import train_test_split
X = labeled_data.drop(columns=["label"], axis=1)
y = labeled_data["label"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=12345)


# In[151]:


from sklearn.tree import DecisionTreeClassifier 
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import KFold


# In[152]:


#Decision Tree Algorithm
decision_model = DecisionTreeClassifier()

#KNN Algorithm
knn_model = KNeighborsClassifier()

#Logistic Regression Algorithm
logistic_model = LogisticRegression()

#Naive Bayes Algorithm
naive_model = GaussianNB()


# In[153]:


from sklearn import metrics
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score

def scoreResults(model, X_train, X_test, y_train, y_test):
    y_test_predict = model.predict(np.array(X_test))
    acc = accuracy_score(y_test, y_test_predict)
    f1 = f1_score(y_test, y_test_predict, average="macro")
    precision = precision_score(y_test, y_test_predict, average="macro")
    recall = recall_score(y_test, y_test_predict, average="macro")
    return [acc, f1, precision, recall]


# In[154]:


def dic2bar(title, dic):
    keys = dic.keys()
    values = dic.values()
    plt.xticks(rotation=90)
    plt.title(title)
    plt.bar(keys, values)
    plt.show()


# In[155]:


def regressionAlgorithm(reg_model, X_train, X_test, y_train, y_test, reg_name):
    model = reg_model
    k = 10
    iter = 1
    cv = KFold(n_splits=k, random_state = 0, shuffle=True)
    print(reg_name, "Scores")
    
    acc_values = {}
    f1_values = {}
    precision_values = {}
    recall_values = {}
    
    for train_index, test_index in cv.split(X):
        X_train, X_test, y_train, y_test = X[train_index], X[test_index], y[train_index], y[test_index]
        model.fit(np.array(X_train.astype('int')), np.array(y_train.astype('int')))
        
        result = scoreResults(model = model
                          ,X_train = X_train.astype('int')
                          ,X_test = X_test.astype('int')
                          ,y_train = y_train.astype('int')
                          ,y_test = y_test.astype('int'))
        
        print(f"{iter}. veri kesiti")
        print("Model Accuracy = ", result[0])
        print("F1 = ", result[1])
        print("PRECISION = ", result[2])
        print("RECALL = ", result[3])
        print("")
        
        acc_values[str(iter) + ". veri kesiti"] = result[0]
        f1_values[str(iter) + ". veri kesiti"] = result[1]
        precision_values[str(iter) + ". veri kesiti"] = result[2]
        recall_values[str(iter) + ". veri kesiti"] = result[3]
        
        iter += 1
    
    dic2bar("Accuracy Scores", acc_values)
    print(acc_values)
    dic2bar("F1 Values", f1_values)
    print(f1_values)
    dic2bar("precision values", precision_values)
    print(precision_values)
    dic2bar("Recall Values", recall_values)
    print(recall_values)


# In[156]:


from sklearn.model_selection import train_test_split
X=labeled_data.iloc[:,:-1].values
y=labeled_data['label'].values
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)


# In[157]:


#3. veri kesiti
#Model Accuracy =  0.9978666666666667
#F1 =  0.9978632085748491
#PRECISION =  0.9978632060082744
#RECALL =  0.9978632211192084
regressionAlgorithm(decision_model, np.array(X_train.astype('int')), np.array(X_test.astype('int')), np.array(y_train.astype('int')), np.array(y_test.astype('int')), 'Decision Tree Algorithm')


# In[158]:


#8. veri kesiti
#Model Accuracy =  0.9992
#F1 =  0.9992005641888035
#PRECISION =  0.9991981174587102
#RECALL =  0.999204079528006
regressionAlgorithm(knn_model, np.array(X_train.astype('int')), np.array(X_test.astype('int')), np.array(y_train.astype('int')), np.array(y_test.astype('int')), 'KNN')


# In[ ]:


regressionAlgorithm(logistic_model, np.array(X_train.astype('int')), np.array(X_test.astype('int')), np.array(y_train.astype('int')), np.array(y_test.astype('int')), 'LOGISTIC REGRESSION')


# In[ ]:


regressionAlgorithm(naive_model, np.array(X_train.astype('int')), np.array(X_test.astype('int')), np.array(y_train.astype('int')), np.array(y_test.astype('int')), 'NAIVE BAYES')


# In[ ]:




