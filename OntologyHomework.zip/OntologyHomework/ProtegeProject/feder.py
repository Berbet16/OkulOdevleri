from SPARQLWrapper import SPARQLWrapper, XML, N3, RDF,JSON
from pprint import pprint
from datetime import datetime

sparql = SPARQLWrapper("http://localhost:3030/ds/query")

sparql.setQuery("""
PREFIX onto: <http://www.semanticweb.org/bs/ontologies/2022/0/astrology#>
PREFIX dbr: <http://dbpedia.org/resource/>
PREFIX dbo: <http://dbpedia.org/ontology/>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX dbp: <http://dbpedia.org/property/>
SELECT DISTINCT ?X ?person
WHERE {    
    ?X onto:cooks ?Y ;
    SERVICE <http://dbpedia.org/sparql>
    {
     ?person rdf:type dbo:Chef ;
      dbp:ratings "Michelin Stars"@en .
    }
}
LIMIT 10
"""

)
sparql.setReturnFormat(JSON)   # Return format is JSON
results = sparql.query().convert()

file = open("sample.html","w")

file.write('<html><head><title>All Chefs With Michelin Stars</title></head>')
date = datetime.today().strftime("%A  %B %d")
file.write('<body>')
file.write('<h1>All Chefs With Michelin Stars</h1>')
#extract Weekday %A / Month %B / Day of the Month %d by formatting today's date accordingly
file.write('<table style="width:75%">')
file.write('<ul>')

for result in results["results"]["bindings"]:
    if ("X" in result):
        owlname = result["X"]["value"].split('#')[-1]
    else:
        owlname = 'NONE' 
    if ("person" in result):
        personname = result["person"]["value"].split('/')[-1]
    else:
        personname = 'NONE'   


    file.write('<tr><td style="text-align: justify;">{}</td><td> {} </td></tr>'.format( owlname, personname))
file.write('</ul>')
file.write('</table>')
file.write('</body></html>')

